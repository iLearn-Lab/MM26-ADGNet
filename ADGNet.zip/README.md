<div align="center">
<h2 align="center">
    <b>(ACM MM-2026) ADGNet: Asymmetric Dual-text Guided Network for Infrared Small Target Detection
</h2>
<div>
<a target="_blank" href="">Tongtong&#160;Wang</a><sup>1</sup>,
<a target="_blank" href="">Mingzhu&#160;Xu</a><sup>1&#9993</sup>,
<a target="_blank" href="">Chenglong&#160;Yu</a><sup>1</sup>,
<a target="_blank" href="">Jing&#160;Wang</a><sup>1</sup>,
<a target="_blank" href="">Xiaohui&#160;Lin</a><sup>1</sup>,
<a target="_blank" href="">Weili&#160;Guan</a><sup>2</sup>,
</div>
<sup>1</sup>School of Software, Shandong University&#160&#160&#160</span>
<sup>2</sup>Harbin Institute of Technology, Shenzhen&#160&#160&#160</span>
<br />
<sup>&#9993&#160;</sup>Corresponding author&#160;&#160;</span>
<br/>
<div align="center">
    <a href="" target="_blank">
    <img src="https://img.shields.io/badge/ACM MM-2026-blue.svg?style=flat-square" alt="MM 2026"></a>
    <a href="" target="_blank">
    <img src="https://img.shields.io/badge/Hugging%20Face-Datasets-green" alt="Hugging Face Datasets"</a>
    <a href="" target="_blank">
    <img src="https://img.shields.io/badge/Hugging%20Face-Model-yellow" alt="Hugging Face Model"</a>
</div>
</div>


## Table of Contents

- [Updates](#updates)
- [Introduction](#introduction)
- [Highlights](#highlights)
- [Method / Framework](#method--framework)
- [Project Structure](#project-structure)
- [Installation](#installation)
- [Checkpoints / Models](#checkpoints--models)
- [Dataset / Benchmark](#dataset--benchmark)
- [Usage](#usage)
- [ Visualization](#visualization)
- [Citation](#citation)
- [Acknowledgement](#acknowledgement)
- [License](#license)

---

## 📢 Updates

- 🤗 **[08/2026]** Model **checkpoints** of the SOTA methods and **text data** are released on **Hugging Face**.
- 💻 **[08/2026]** **Source code** is now publicly available.
- 🎉 **[07/2026]** Our paper was accepted by **ACM Multimedia 2026 (ACM MM 2026)**.

## 📖 Introduction

This repository provides the official implementation of **ADGNet: Asymmetric Dual-text Guided Network for Infrared Small Target Detection**, accepted by **ACM Multimedia 2026 (ACM MM 2026)**.

Infrared Small Target Detection (IRSTD) aims to accurately segment weak and tiny targets from complex infrared backgrounds. Existing pure-vision methods rely solely on pixel-level information and often struggle to distinguish small targets from background clutter. Meanwhile, existing vision-language methods typically describe targets and backgrounds using a single textual prompt, overlooking their inherent semantic asymmetry and introducing feature optimization conflicts.

To address these limitations, we propose **ADGNet**, an **Asymmetric Dual-text Guided Network** for infrared small target detection. Its main components include:

- **Asymmetric Dual-text Prompt (ADP):** employs an abstract, image-independent target prompt and a detailed, image-dependent background prompt to provide dedicated semantic guidance.
- **Asymmetric Dual-Branch Interaction (ADBI):** separately constructs a Target Localization branch and a Background Suppression branch to enhance weak targets and suppress complex clutter.
- **Adaptive Feature Aggregation (AFA):** dynamically integrates the features produced by the two branches to achieve accurate target segmentation.

We also construct the **Asymmetric Image-Text Infrared (AITIR)** dataset by providing asymmetric text annotations for three widely used infrared small target datasets: **IRSTD-1K**, **NUDT-SIRST**, and **SIRST**. Extensive experiments demonstrate that ADGNet achieves competitive performance against 21 state-of-the-art methods.

This repository provides:

- 💻 Training and inference code for ADGNet
- 🏆 Model checkpoints of the SOTA methods
- 📝 AITIR asymmetric text annotations
- 🛠️ Data preprocessing scripts
- 📊 Evaluation scripts
